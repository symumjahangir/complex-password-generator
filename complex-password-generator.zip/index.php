<?php 
    if (isset($_POST['generate'])) {

        $post_uppr_case = $_POST['uppr_case'];
        $post_lowr_case = $_POST['lowr_case'];
        $post_ambg_case = $_POST['ambg_case'];
        $post_nmbr_case = $_POST['nmbr_case'];
        $post_spec_case = $_POST['spec_case'];

        $uppr_case = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        $lowr_case = "abcdefghijklmnopqrstuvwxyz";
        $ambg_case = "({}[]()/\'`~,;:.<>)";
        $nmbr_case = "0123456789";
        $spec_case = "!@#$%^&*";
        
        $gen_uppr_case = substr(str_shuffle($uppr_case),0,$post_uppr_case);
        $gen_lowr_case = substr(str_shuffle($lowr_case),0,$post_lowr_case);
        $gen_ambg_case = substr(str_shuffle($ambg_case),0,$post_ambg_case);
        $gen_nmbr_case = substr(str_shuffle($nmbr_case),0,$post_nmbr_case);
        $gen_spec_case = substr(str_shuffle($spec_case),0,$post_spec_case);

        $mixed = "$gen_uppr_case$gen_lowr_case$gen_ambg_case$gen_nmbr_case$gen_spec_case";
        $sum = $post_uppr_case+$post_lowr_case+$post_ambg_case+$post_nmbr_case+$post_spec_case;
        $gen_mixed = substr(str_shuffle($mixed),0,$sum);

        // echo $sum;
        // error_reporting(0);
        // echo $gen_mixed;

    }

    error_reporting(0); if ($gen_mixed > NULL) {
        $gen_mixed = $gen_mixed;
    } else $gen_mixed = "Please provide your requirement";

    error_reporting(0); if ($sum > 0) {
        $sum = $sum;
    } else $sum = 0;

?>

<!-- Please Input the Number of Characters and Hit 'Generater' -->
<!-- Requirement -->

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="resource/css/design.css">
    <title>QpasS Gen</title>
</head>

<body>
    <div class="wrap">
        <h2> Generate Your Complex PassWord</h2>
        <form action="index.php" method="POST">
            Number of UpperC: <select name="uppr_case">
                <option value="0">00</option>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select> <br><br>
            Number of LowerC: <select name="lowr_case">
                <option value="0">00</option>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select><br><br>
            Number of AmbigC: <select name="ambg_case">
                <option value="0">00</option>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select><br><br>
            Number of Numeric: <select name="nmbr_case">
                <option value="0">00</option>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select><br><br>
            Number of Specialc: <select name="spec_case">
                <option value="0">00</option>
                <option value="1">01</option>
                <option value="2">02</option>
                <option value="3">03</option>
                <option value="4">04</option>
                <option value="5">05</option>
                <option value="6">06</option>
                <option value="7">07</option>
                <option value="8">08</option>
                <option value="9">09</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
            </select><br><br>
            <input type="submit" value="Generate" name="generate">
            <!-- <input type="text" value="PassWord"> -->
            <section>
            <p><?php echo $gen_mixed; ?></p>
            <p>Total <?php echo $sum; ?> Characters </p>
            </section>
            
            <!-- <p class="pc">PassworD</p> -->
        </form>
    </div>
</body>

</html>

